// Copyright (C) 2009-2026 Joel Rosdahl and other contributors
//
// See doc/authors.adoc for a complete list of contributors.
//
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 3 of the License, or (at your option)
// any later version.
//
// This program is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
// FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
// more details.
//
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 51
// Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA

#pragma once

#include <ccache/hash.hpp>
#include <ccache/util/bitset.hpp>

#include <cstddef>
#include <filesystem>
#include <optional>
#include <string>
#include <string_view>

class Config;
class Context;

// The result of scanning source code.
//
// Note: Probably need to bump Inode cache version if changing values or
// semantics of this enum.
enum class SourceCodeScan {
  none = 0,
  found_date = 1U << 0,
  found_time = 1U << 1,
  found_timestamp = 1U << 2,
  found_embed = 1U << 3,
  found_incbin = 1U << 4,
};

using SourceCodeScanResult = util::BitSet<SourceCodeScan>;

#ifdef HAVE_AVX2
// Search for source code patterns in `str`, AVX2 version.
SourceCodeScanResult check_for_source_code_patterns_avx2(std::string_view str);
#endif

// Search for source code patterns in `str`, non-SIMD version.
SourceCodeScanResult
check_for_source_code_patterns_scalar(std::string_view str);

// Return the position of the next incbin directive in `str` or
// `std::string_view::npos` if not found.
size_t find_incbin_directive(std::string_view str, size_t start = 0);

// Return the value of the first "-triple" argument in `-###` output from a
// Clang driver or an empty string if not found.
std::string_view find_clang_cc1_triple(std::string_view driver_output);

// Hash a source code file using the inode cache if enabled.
std::optional<Hash::Digest> hash_source_code_file(
  Context& ctx, const std::filesystem::path& path, size_t size_hint = 0);

// Hash a binary file (using the inode cache if enabled) and put its digest in
// `digest`
std::optional<Hash::Digest> hash_binary_file(const Context& ctx,
                                             const std::filesystem::path& path,
                                             size_t size_hint = 0);

// Hash a binary file (using the inode cache if enabled) and hash the digest to
// `hash`.
//
// Returns true on success, otherwise false.
bool hash_binary_file(const Context& ctx,
                      Hash& hash,
                      const std::filesystem::path& path);

// Hash the output of `command` (not executed via a shell). A "%compiler%"
// string in `command` will be replaced with `compiler`.
bool hash_command_output(Hash& hash,
                         const std::string& command,
                         const std::string& compiler);

// Like `hash_command_output` but for each semicolon-separated command in
// `command`.
bool hash_multicommand_output(Hash& hash,
                              const std::string& command,
                              const std::string& compiler);
