// Copyright (C) 2020-2026 Joel Rosdahl and other contributors
//
// See doc/authors.adoc for a complete list of contributors.
//
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 3 of the License, or (at your option)
// any later version.
//
// This program is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
// FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
// more details.
//
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 51
// Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA

#include "testutil.hpp"

#include <ccache/config.hpp>
#include <ccache/context.hpp>
#include <ccache/hash.hpp>
#include <ccache/inodecache.hpp>
#include <ccache/util/fd.hpp>
#include <ccache/util/file.hpp>
#include <ccache/util/filesystem.hpp>
#include <ccache/util/path.hpp>
#include <ccache/util/temporaryfile.hpp>
#include <ccache/util/time.hpp>
#include <ccache/util/wincompat.hpp>

#include <doctest/doctest.h>

#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>

#include <chrono>

namespace fs = util::filesystem;

using namespace std::chrono_literals;

using TestUtil::TestContext;

namespace {

bool
inode_cache_available()
{
  auto tmp_file =
    util::TemporaryFile::create((*fs::current_path()) / "fs_test");
  if (!tmp_file) {
    return false;
  }
  bool available = tmp_file->fd && InodeCache::available(*tmp_file->fd);
  tmp_file->fd.close();
  std::ignore = fs::remove(tmp_file->path);
  return available;
}

void
init(Config& config)
{
  config.set_debug(true);
  config.set_inode_cache(true);
  config.set_temporary_dir(*fs::current_path());
}

bool
put(InodeCache& inode_cache,
    InodeCache::ContentType content_type,
    const std::string& filename,
    const std::string& str,
    SourceCodeScanResult return_value)
{
  return inode_cache.put(
    filename, content_type, Hash().hash(str).digest(), return_value);
}

#ifdef _WIN32
bool
set_creation_time(const std::string& path, util::TimePoint time)
{
  const uint64_t intervals =
    static_cast<uint64_t>(util::nsec_tot(time) / 100) + 116444736000000000;
  FILETIME filetime = {static_cast<DWORD>(intervals),
                       static_cast<DWORD>(intervals >> 32)};
  HANDLE handle =
    CreateFileA(path.c_str(),
                FILE_WRITE_ATTRIBUTES,
                FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
                nullptr,
                OPEN_EXISTING,
                0,
                nullptr);
  if (handle == INVALID_HANDLE_VALUE) {
    return false;
  }
  BOOL ret = SetFileTime(handle, &filetime, nullptr, nullptr);
  CloseHandle(handle);
  return ret;
}
#endif

} // namespace

TEST_SUITE_BEGIN("InodeCache" * doctest::skip(!inode_cache_available()));

TEST_CASE("Test disabled")
{
  TestContext test_context;

  Config config;
  init(config);
  config.set_inode_cache(false);
  InodeCache inode_cache(config, 0ns);

  CHECK(!inode_cache.get("a",
                         InodeCache::ContentType::checked_for_temporal_macros));
  CHECK(!inode_cache.put("a",
                         InodeCache::ContentType::checked_for_temporal_macros,
                         Hash::Digest(),
                         SourceCodeScanResult()));
  CHECK(inode_cache.get_hits() == -1);
  CHECK(inode_cache.get_misses() == -1);
  CHECK(inode_cache.get_errors() == -1);
}

TEST_CASE("Test lookup nonexistent")
{
  TestContext test_context;

  Config config;
  init(config);

  InodeCache inode_cache(config, 0ns);
  REQUIRE(util::write_file("a", ""));

  CHECK(!inode_cache.get("a",
                         InodeCache::ContentType::checked_for_temporal_macros));
  CHECK(inode_cache.get_hits() == 0);
  CHECK(inode_cache.get_misses() == 1);
  CHECK(inode_cache.get_errors() == 0);
}

TEST_CASE("Test put and lookup")
{
  TestContext test_context;

  Config config;
  init(config);

  InodeCache inode_cache(config, 0ns);
  REQUIRE(util::write_file("a", "a text"));

  SourceCodeScanResult result;
  result.insert(SourceCodeScan::found_date);
  CHECK(put(inode_cache,
            InodeCache::ContentType::checked_for_temporal_macros,
            "a",
            "a text",
            result));

  auto return_value =
    inode_cache.get("a", InodeCache::ContentType::checked_for_temporal_macros);
  REQUIRE(return_value);
  CHECK(return_value->first.to_bitmask()
        == static_cast<int>(SourceCodeScan::found_date));
  CHECK(return_value->second == Hash().hash("a text").digest());
  CHECK(inode_cache.get_hits() == 1);
  CHECK(inode_cache.get_misses() == 0);
  CHECK(inode_cache.get_errors() == 0);

  REQUIRE(util::write_file("a", "something else"));

  CHECK(!inode_cache.get("a",
                         InodeCache::ContentType::checked_for_temporal_macros));
  CHECK(inode_cache.get_hits() == 1);
  CHECK(inode_cache.get_misses() == 1);
  CHECK(inode_cache.get_errors() == 0);

  CHECK(put(inode_cache,
            InodeCache::ContentType::checked_for_temporal_macros,
            "a",
            "something else",
            SourceCodeScanResult(SourceCodeScan::found_time)));

  return_value =
    inode_cache.get("a", InodeCache::ContentType::checked_for_temporal_macros);
  REQUIRE(return_value);
  CHECK(return_value->first.to_bitmask()
        == static_cast<int>(SourceCodeScan::found_time));
  CHECK(return_value->second == Hash().hash("something else").digest());
  CHECK(inode_cache.get_hits() == 2);
  CHECK(inode_cache.get_misses() == 1);
  CHECK(inode_cache.get_errors() == 0);
}

TEST_CASE("Drop file")
{
  TestContext test_context;

  Config config;
  init(config);

  InodeCache inode_cache(config, 0ns);

  inode_cache.get("a", InodeCache::ContentType::raw);
  CHECK(util::DirEntry(inode_cache.get_path()));
  CHECK(inode_cache.drop());
  CHECK(!util::DirEntry(inode_cache.get_path()));
  CHECK(inode_cache.drop());
}

TEST_CASE("Test content type")
{
  TestContext test_context;

  Config config;
  init(config);

  InodeCache inode_cache(config, 0ns);
  REQUIRE(util::write_file("a", "a text"));
  auto binary_digest = Hash().hash("binary").digest();
  auto code_digest = Hash().hash("code").digest();

  CHECK(inode_cache.put("a",
                        InodeCache::ContentType::raw,
                        binary_digest,
                        SourceCodeScanResult(SourceCodeScan::found_date)));
  CHECK(inode_cache.put("a",
                        InodeCache::ContentType::checked_for_temporal_macros,
                        code_digest,
                        SourceCodeScanResult(SourceCodeScan::found_time)));

  auto return_value = inode_cache.get("a", InodeCache::ContentType::raw);
  REQUIRE(return_value);
  CHECK(return_value->first.to_bitmask()
        == static_cast<int>(SourceCodeScan::found_date));
  CHECK(return_value->second == binary_digest);

  return_value =
    inode_cache.get("a", InodeCache::ContentType::checked_for_temporal_macros);
  REQUIRE(return_value);
  CHECK(return_value->first.to_bitmask()
        == static_cast<int>(SourceCodeScan::found_time));
  CHECK(return_value->second == code_digest);
}

TEST_CASE("Files with the same size and times have separate entries")
{
  TestContext test_context;

  Config config;
  init(config);

  InodeCache inode_cache(config, 0ns);
  REQUIRE(util::write_file("a", "a text"));
  REQUIRE(util::write_file("b", "b text"));
  const auto time = util::now();
  util::set_timestamps("a", time);
  util::set_timestamps("b", time);
#ifdef _WIN32
  REQUIRE(set_creation_time("a", time));
  REQUIRE(set_creation_time("b", time));
#endif

  CHECK(put(inode_cache,
            InodeCache::ContentType::raw,
            "a",
            "a text",
            SourceCodeScanResult()));
  CHECK(!inode_cache.get("b", InodeCache::ContentType::raw));
}

TEST_SUITE_END();
