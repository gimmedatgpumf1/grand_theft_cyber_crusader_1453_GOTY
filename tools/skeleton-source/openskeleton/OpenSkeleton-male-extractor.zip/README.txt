1. Extract this ZIP to a folder.
2. Put the Zenodo NM_combined.mat file in the same folder.
3. Double-click extract-male.cmd. Python 3 is required.
4. Upload male-N197925.npz and male-N197925.json.

Faces.mat is already included and checksum-verified. Depending on the MATLAB
file format, extraction may require several GB of RAM. If it fails, send the
error shown in the window. The full 2.5 GB file has not yet been tested here.

Faces.mat: OpenSkeleton, Duquesne K., BioCAT, Destryker T., Segers V. and
Audenaert E., Ghent University; CC BY 4.0. Source: https://zenodo.org/records/22833546
